public class Principal {



    public static void main(String[] args) {
        Tripla<Integer,String,Integer> tripla = new Tripla<>(1,"Patata",3);

        System.out.println(tripla.toString());

    }


}
